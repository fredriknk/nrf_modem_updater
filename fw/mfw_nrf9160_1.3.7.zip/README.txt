This release includes FOTA update from mfw_nrf9160_1.3.6 release to mfw_nrf9160_1.3.7 release.
FOTA update filename is mfw_nrf9160_update_from_1.3.6_to_1.3.7.bin.

Non-wired full modem update can be performed by using new MFW CBOR image format and suitable support from the nRF Connect SDK and device hardware.

This release includes FOTA-TEST images between mfw_nrf9160_1.3.7 release and mfw_nrf9160_1.3.7-FOTA-TEST image.
FOTA test update filenames are mfw_nrf9160_update_from_1.3.7_to_1.3.7-FOTA-TEST and mfw_nrf9160_update_from_1.3.7-FOTA-TEST_to_1.3.7.

UUID of mfw_nrf9160_1.3.7 is e7a1c54a-b07c-4512-9c3e-8ecbbfe2641d
UUID of mfw_nrf9160_1.3.7-FOTA-TEST is 23e3e810-554a-46ff-865f-131928fcca44